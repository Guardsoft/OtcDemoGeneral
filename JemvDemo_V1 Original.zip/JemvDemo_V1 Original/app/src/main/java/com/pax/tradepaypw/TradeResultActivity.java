package com.pax.tradepaypw;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

import com.pax.dal.entity.EReaderType;
import com.pax.jemv.amex.api.ClssAmexApi;
import com.pax.jemv.clcommon.ByteArray;
import com.pax.jemv.clcommon.KernType;
import com.pax.jemv.clcommon.TransactionPath;
import com.pax.jemv.clssentrypoint.trans.ClssEntryPoint;
import com.pax.jemv.clssquickpass.trans.ClssQuickPass;
import com.pax.jemv.demo.R;
import com.pax.jemv.dpas.api.ClssDPASApi;
import com.pax.jemv.emv.api.EMVCallback;
import com.pax.jemv.jcb.api.ClssJCBApi;
import com.pax.jemv.paypass.api.ClssPassApi;
import com.pax.jemv.paywave.api.ClssWaveApi;
import com.pax.jemv.pure.api.ClssPUREApi;
import com.pax.jemv.qpboc.api.ClssPbocApi;

import java.text.SimpleDateFormat;
import java.util.Date;

import static com.pax.tradepaypw.utils.Utils.bcd2Str;

public class TradeResultActivity extends AppCompatActivity {
    private static final String TAG = "TradeResultActivity";
    private TextView tvAmount;
    private TextView tvCardNum;
    private TextView tvDate;

    private TextView tvArqc;
    private TextView tvApplable;
    private TextView tvAid;
    private TextView tvAppname;
    private TextView tvTsi;
    private TextView tvTc;
    private TextView tvAtc;
    private TextView tvTvr;
    private Handler handler = new Handler();
    private ClssEntryPoint entryPoint = ClssEntryPoint.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        initView();
        initData();


        //singleTask模式
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(TradeResultActivity.this, MainActivity.class);
                startActivity(intent);
            }
        }, 50000);

    }

    //here1
    private void initData() {
        String arqc = null;
        String tvr = null;
        String aid = null;
        String appLable = null;
        String appName = null;
        String tsi = null;
        String tc = null;
        String atc = null;
        int iRet;

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ByteArray byteArray = new ByteArray();
        Log.i(TAG, "entryPoint.getOutParam().ucKernType = " + entryPoint.getOutParam().ucKernType);
        if (SwingCardActivity.getReadType() == EReaderType.PICC) {
            if (entryPoint.getOutParam().ucKernType == KernType.KERNTYPE_MC) {
                ClssPassApi.Clss_GetTLVDataList_MC(new byte[]{(byte) 0x9F, 0x26}, (byte) 2, 10, byteArray);
                byte[] a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                arqc = bcd2Str(a);
                iRet = ClssPassApi.Clss_GetTLVDataList_MC(new byte[]{(byte) 0x95}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tvr = bcd2Str(a);
                Log.i("Clss_TLV_MC iRet 0x95", Integer.toString(iRet));
                Log.i("Clss_GetTLV_MC TVR 0x95", tvr + "");
                ClssPassApi.Clss_GetTLVDataList_MC(new byte[]{(byte) 0x4F}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                aid = bcd2Str(a);
                ClssPassApi.Clss_GetTLVDataList_MC(new byte[]{(byte) 0x50}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appLable = new String(a);
                ClssPassApi.Clss_GetTLVDataList_MC(new byte[]{(byte) 0x9F, 0x12}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appName = new String(a);
                ClssPassApi.Clss_GetTLVDataList_MC(new byte[]{(byte) 0x9B}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tsi = bcd2Str(a);
                ClssPassApi.Clss_GetTLVDataList_MC(new byte[]{(byte) 0x9F, 0x26}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tc = bcd2Str(a);
                ClssPassApi.Clss_GetTLVDataList_MC(new byte[]{(byte) 0x9F, 0x36}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                atc = bcd2Str(a);

            } else if (entryPoint.getOutParam().ucKernType == KernType.KERNTYPE_VIS) {
                ClssWaveApi.Clss_GetTLVData_Wave((short) 0x9F26, byteArray);
                byte[] a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                arqc = bcd2Str(a);
                ClssWaveApi.Clss_GetTLVData_Wave((short) 0x95, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tvr = bcd2Str(a);
                ClssWaveApi.Clss_GetTLVData_Wave((short) 0x4F, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                aid = bcd2Str(a);
                ClssWaveApi.Clss_GetTLVData_Wave((short) 0x50, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appLable = new String(a);
                ClssWaveApi.Clss_GetTLVData_Wave((short) 0x9F12, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appName = new String(a);
                ClssWaveApi.Clss_GetTLVData_Wave((short) 0x9B, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tsi = bcd2Str(a);
                ClssWaveApi.Clss_GetTLVData_Wave((short) 0x9F26, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tc = bcd2Str(a);
                ClssWaveApi.Clss_GetTLVData_Wave((short) 0x9F36, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                atc = bcd2Str(a);
            } else if (entryPoint.getOutParam().ucKernType == KernType.KERNTYPE_AE) {
                ClssAmexApi.Clss_GetTLVData_AE((short) 0x9F26, byteArray);
                byte[] a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                arqc = bcd2Str(a);
                ClssAmexApi.Clss_GetTLVData_AE((short) 0x95, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tvr = bcd2Str(a);
                ClssAmexApi.Clss_GetTLVData_AE((short) 0x4F, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                aid = bcd2Str(a);
                ClssAmexApi.Clss_GetTLVData_AE((short) 0x50, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appLable = new String(a);
                ClssAmexApi.Clss_GetTLVData_AE((short) 0x9F12, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appName = new String(a);
                ClssAmexApi.Clss_GetTLVData_AE((short) 0x9B, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tsi = bcd2Str(a);
                ClssAmexApi.Clss_GetTLVData_AE((short) 0x9F26, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tc = bcd2Str(a);
                ClssAmexApi.Clss_GetTLVData_AE((short) 0x9F36, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                atc = bcd2Str(a);
            } else if (entryPoint.getOutParam().ucKernType == KernType.KERNTYPE_ZIP) {
                ClssDPASApi.Clss_GetTLVDataList_DPAS(new byte[]{(byte) 0x9F, 0x26}, (byte) 2, 10, byteArray);
                byte[] a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                arqc = bcd2Str(a);
                ClssDPASApi.Clss_GetTLVDataList_DPAS(new byte[]{(byte) 0x95}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tvr = bcd2Str(a);
                ClssDPASApi.Clss_GetTLVDataList_DPAS(new byte[]{(byte) 0x4F}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                aid = bcd2Str(a);
                ClssDPASApi.Clss_GetTLVDataList_DPAS(new byte[]{(byte) 0x50}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appLable = new String(a);
                ClssDPASApi.Clss_GetTLVDataList_DPAS(new byte[]{(byte) 0x9F, 0x12}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appName = new String(a);
                ClssDPASApi.Clss_GetTLVDataList_DPAS(new byte[]{(byte) 0x9B}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tsi = bcd2Str(a);
                ClssDPASApi.Clss_GetTLVDataList_DPAS(new byte[]{(byte) 0x9F, 0x26}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tc = bcd2Str(a);
                ClssDPASApi.Clss_GetTLVDataList_DPAS(new byte[]{(byte) 0x9F, 0x36}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                atc = bcd2Str(a);
            } else if ((entryPoint.getOutParam().ucKernType == KernType.KERNTYPE_PBOC) &&
                    (ClssQuickPass.getInstance().getTransPath() == TransactionPath.CLSS_VISA_QVSDC)) {
                ClssPbocApi.Clss_GetTLVData_Pboc((short) 0x9F26, byteArray);
                byte[] a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                arqc = bcd2Str(a);
                ClssPbocApi.Clss_GetTLVData_Pboc((short) 0x95, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tvr = bcd2Str(a);
                ClssPbocApi.Clss_GetTLVData_Pboc((short) 0x4F, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                aid = bcd2Str(a);
                ClssPbocApi.Clss_GetTLVData_Pboc((short) 0x50, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appLable = new String(a);
                ClssPbocApi.Clss_GetTLVData_Pboc((short) 0x9F12, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appName = new String(a);
                ClssPbocApi.Clss_GetTLVData_Pboc((short) 0x9B, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tsi = bcd2Str(a);
                ClssPbocApi.Clss_GetTLVData_Pboc((short) 0x9F26, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tc = bcd2Str(a);
                ClssPbocApi.Clss_GetTLVData_Pboc((short) 0x9F36, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                atc = bcd2Str(a);
            } else if (entryPoint.getOutParam().ucKernType == KernType.KERNTYPE_JCB) {
                ClssJCBApi.Clss_GetTLVDataList_JCB(new byte[]{(byte) 0x9F, 0x26}, (byte) 2, 10, byteArray);
                byte[] a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                arqc = bcd2Str(a);
                byteArray = new ByteArray();
                iRet = ClssJCBApi.Clss_GetTLVDataList_JCB(new byte[]{(byte) 0x95}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tvr = bcd2Str(a);
                Log.i("Clss_TLV_MC iRet 0x95", Integer.toString(iRet));
                Log.i("Clss_GetTLV_MC TVR 0x95", tvr + "");
                byteArray = new ByteArray();
                ClssJCBApi.Clss_GetTLVDataList_JCB(new byte[]{(byte) 0x4F}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                aid = bcd2Str(a);
                byteArray = new ByteArray();
                ClssJCBApi.Clss_GetTLVDataList_JCB(new byte[]{(byte) 0x50}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appLable = new String(a);
                byteArray = new ByteArray();
                ClssJCBApi.Clss_GetTLVDataList_JCB(new byte[]{(byte) 0x9F, 0x12}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appName = new String(a);
                byteArray = new ByteArray();
                ClssJCBApi.Clss_GetTLVDataList_JCB(new byte[]{(byte) 0x9B}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tsi = bcd2Str(a);
                byteArray = new ByteArray();
                ClssJCBApi.Clss_GetTLVDataList_JCB(new byte[]{(byte) 0x9F, 0x26}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tc = bcd2Str(a);
                byteArray = new ByteArray();
                ClssJCBApi.Clss_GetTLVDataList_JCB(new byte[]{(byte) 0x9F, 0x36}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                atc = bcd2Str(a);
            } else if (entryPoint.getOutParam().ucKernType == KernType.KERNTYPE_PURE) {
                ClssPUREApi.Clss_GetTLVDataList_PURE(new byte[]{(byte) 0x9F, 0x26}, (byte) 2, 10, byteArray);
                byte[] a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                arqc = bcd2Str(a);
                byteArray = new ByteArray();
                iRet = ClssPUREApi.Clss_GetTLVDataList_PURE(new byte[]{(byte) 0x95}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tvr = bcd2Str(a);
                Log.i("Clss_TLV_MC iRet 0x95", Integer.toString(iRet));
                Log.i("Clss_GetTLV_MC TVR 0x95", tvr + "");
                byteArray = new ByteArray();
                ClssPUREApi.Clss_GetTLVDataList_PURE(new byte[]{(byte) 0x4F}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                aid = bcd2Str(a);
                byteArray = new ByteArray();
                ClssPUREApi.Clss_GetTLVDataList_PURE(new byte[]{(byte) 0x50}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appLable = new String(a);
                byteArray = new ByteArray();
                ClssPUREApi.Clss_GetTLVDataList_PURE(new byte[]{(byte) 0x9F, 0x12}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                appName = new String(a);
                byteArray = new ByteArray();
                ClssPUREApi.Clss_GetTLVDataList_PURE(new byte[]{(byte) 0x9B}, (byte) 1, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tsi = bcd2Str(a);
                byteArray = new ByteArray();
                ClssPUREApi.Clss_GetTLVDataList_PURE(new byte[]{(byte) 0x9F, 0x26}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                tc = bcd2Str(a);
                byteArray = new ByteArray();
                ClssPUREApi.Clss_GetTLVDataList_PURE(new byte[]{(byte) 0x9F, 0x36}, (byte) 2, 10, byteArray);
                a = new byte[byteArray.length];
                System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
                atc = bcd2Str(a);
            }
        }
        if ((SwingCardActivity.getReadType() == EReaderType.ICC) ||
                ((ClssEntryPoint.getInstance().getOutParam().ucKernType == KernType.KERNTYPE_PBOC) && (ClssQuickPass.getInstance().getTransPath() == TransactionPath.CLSS_VISA_VSDC))) { // contact
            EMVCallback.EMVGetTLVData((short) 0x9F26, byteArray);
            byte[] a = new byte[byteArray.length];
            System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
            arqc = bcd2Str(a);
            EMVCallback.EMVGetTLVData((short) 0x95, byteArray);
            a = new byte[byteArray.length];
            System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
            tvr = bcd2Str(a);
            EMVCallback.EMVGetTLVData((short) 0x4F, byteArray);
            a = new byte[byteArray.length];
            System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
            aid = bcd2Str(a);
            EMVCallback.EMVGetTLVData((short) 0x50, byteArray);
            a = new byte[byteArray.length];
            System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
            appLable = bcd2Str(a);
            EMVCallback.EMVGetTLVData((short) 0x9F12, byteArray);
            a = new byte[byteArray.length];
            System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
            appName = bcd2Str(a);
            EMVCallback.EMVGetTLVData((short) 0x9B, byteArray);
            a = new byte[byteArray.length];
            System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
            tsi = bcd2Str(a);
            EMVCallback.EMVGetTLVData((short) 0x9F26, byteArray);
            a = new byte[byteArray.length];
            System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
            tc = bcd2Str(a);
            EMVCallback.EMVGetTLVData((short) 0x9F36, byteArray);
            a = new byte[byteArray.length];
            System.arraycopy(byteArray.data, 0, a, 0, byteArray.length);
            atc = bcd2Str(a);
        }
        tvDate.setText(dateFormat.format(new Date()));
        tvCardNum.setText(getIntent().getStringExtra("pan"));
        tvAmount.setText(getIntent().getStringExtra("amount"));

        tvArqc.setText(arqc);
        tvApplable.setText(appLable);
        tvAid.setText(aid);
        tvAppname.setText(appName);
        tvTsi.setText(tsi);
        tvTc.setText(tc);
        tvAtc.setText(atc);
        tvTvr.setText(tvr);

    }

    private void initView() {
        tvAmount = (TextView) findViewById(R.id.ecash_amount);
        tvCardNum = (TextView) findViewById(R.id.ecash_bankcardNo);
        tvDate = (TextView) findViewById(R.id.ecash_time);

        tvArqc = (TextView) findViewById(R.id.ecash_arqc);
        tvApplable = (TextView) findViewById(R.id.ecash_applable);
        tvAid = (TextView) findViewById(R.id.ecash_aid);
        tvAppname = (TextView) findViewById(R.id.ecash_appname);
        tvTsi = (TextView) findViewById(R.id.ecash_tsi);
        tvTc = (TextView) findViewById(R.id.ecash_tc);
        tvAtc = (TextView) findViewById(R.id.ecash_atc);
        tvTvr = (TextView) findViewById(R.id.ecash_tvr);
    }

    public void enterClick(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onStop() {
        handler.removeCallbacksAndMessages(null);
        super.onStop();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }

        return super.onKeyDown(keyCode, event);
    }
}
